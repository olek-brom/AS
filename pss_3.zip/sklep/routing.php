<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('hello'); #default action
App::getRouter()->setLoginRoute('login'); #action to forward if no permissions

Utils::addRoute('hello', 'HelloCtrl');
Utils::addRoute('hello_admin', 'HelloCtrl',["administrator"]);
Utils::addRoute('about', 'HelloCtrl');
Utils::addRoute('registerView', 'LoginCtrl');
Utils::addRoute('register', 'LoginCtrl');
Utils::addRoute('loginView', 'LoginCtrl');
Utils::addRoute('login', 'LoginCtrl');
Utils::addRoute('logout', 'LoginCtrl',["klient", "pracownik", "administrator"]);
Utils::addRoute('productView', 'ProductCtrl');
Utils::addRoute('addToCart', 'ProductCtrl',["klient"]);
Utils::addRoute('viewUsers', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('addUserView', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('addUser', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('editUser', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('saveUser', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('deleteUser', 'UsersEditCtrl',["administrator"]);
Utils::addRoute('viewProducts', 'SellerCtrl',["pracownik"]);
Utils::addRoute('addProductView', 'SellerCtrl',["pracownik"]);
Utils::addRoute('addProduct', 'SellerCtrl',["pracownik"]);
Utils::addRoute('editProduct', 'SellerCtrl',["pracownik"]);
Utils::addRoute('deleteProduct', 'SellerCtrl',["pracownik"]);
Utils::addRoute('saveProduct', 'SellerCtrl',["pracownik"]);
Utils::addRoute('viewConfirmedCarts', 'SellerCtrl',["pracownik"]);
Utils::addRoute('viewConfirmedCartsDetails', 'SellerCtrl',["pracownik"]);
Utils::addRoute('sendCart', 'SellerCtrl',["pracownik"]);
Utils::addRoute('cartView', 'CartCtrl',["klient"]);
Utils::addRoute('ordersView', 'CartCtrl',["klient"]);
Utils::addRoute('deleteProductFromCart', 'CartCtrl',["klient"]);
Utils::addRoute('confirmCart', 'CartCtrl',["klient"]);
//Utils::addRoute('action_name', 'controller_class_name');