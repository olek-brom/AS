<?php
/* Smarty version 4.1.0, created on 2023-01-04 22:22:00
  from 'C:\xampp\htdocs\sklep\app\views\editProduct.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63b5edf843bc39_74023135',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '09ae0daa2c31e69f51969bdf701ca8fffae56677' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\editProduct.tpl',
      1 => 1672867104,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63b5edf843bc39_74023135 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_201592328863b5edf8417bf8_86134050', 'maincontent1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_81844945763b5edf84396e4_29369866', 'maincontent2');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_144497879563b5edf843af23_66506883', 'maincontent3');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "seller.tpl");
}
/* {block 'maincontent1'} */
class Block_201592328863b5edf8417bf8_86134050 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_201592328863b5edf8417bf8_86134050',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div class="w3-panel w3-pale-yellow w3-round">
            <p>Błąd:</p><br>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
            <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>    
    <?php }?>
<h4 class="w3-bar-item w3-text-theme"><b>Edycja produktu</b></h4>
<div>
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
saveProduct" method="post" class="w3-container">
	<fieldset>
            <legend>Dane produktu</legend>
            <label for="id">ID</label>
            <input id="id_produkt" type="text" placeholder="id_produkt" name="id_produkt" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['id_produkt'];?>
" readonly>
            <label for="nazwa_produktu">Nazwa produktu</label>
            <input id="nazwa_produktu" type="text" placeholder="nazwa produktu" name="nazwa_produktu" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['nazwa_produktu'];?>
">
            <label for="opis">Opis produktu</label>
            <input id="opis" type="text" placeholder="opis" name="opis" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['opis'];?>
">
            <label for="cena_brutto_dla_klienta">Cena brutto</label>
            <input id="cena_brutto_dla_klienta" type="text" placeholder="cena_brutto_dla_klienta" name="cena_brutto_dla_klienta" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['cena_brutto_dla_klienta'];?>
">
            <label for="id_kategorii">Kategoria</label>
            <br>
            <select name="id_kategorii" id="id_kategorii" class="w3-select">
            <option value="<?php echo $_smarty_tpl->tpl_vars['kategoria']->value['id_kategorii'];?>
"><?php echo $_smarty_tpl->tpl_vars['kategoria']->value['nazwa_kategorii'];?>
</option>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['kategorie']->value, 'k');
$_smarty_tpl->tpl_vars['k']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['k']->value) {
$_smarty_tpl->tpl_vars['k']->do_else = false;
?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['k']->value['id_kategorii'];?>
"><?php echo $_smarty_tpl->tpl_vars['k']->value['nazwa_kategorii'];?>
</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </select>
            <label for="sciezka_plik">Nazwa pliku ze zdjęciem</label>
            <input id="sciezka_plik" type="text" placeholder="sciezka plik" name="sciezka_plik" value="<?php echo $_smarty_tpl->tpl_vars['zdjecie']->value;?>
">
            <div class="">
                    <input type="submit" class="pure-button pure-button-primary" value="Zapisz"/>
                    <a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
viewProducts">Powrót</a>
            </div>
	</fieldset>
</form>	
</div>

<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_81844945763b5edf84396e4_29369866 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_81844945763b5edf84396e4_29369866',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent2'} */
/* {block 'maincontent3'} */
class Block_144497879563b5edf843af23_66506883 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent3' => 
  array (
    0 => 'Block_144497879563b5edf843af23_66506883',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent3'} */
}
