<?php
/* Smarty version 4.1.0, created on 2023-01-03 13:43:43
  from 'C:\xampp\htdocs\sklep\app\views\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63b422ffeb7ff1_38350093',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1106ad3461ab626f5c1f2468c97277d0fba2a35e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\login.tpl',
      1 => 1672749817,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63b422ffeb7ff1_38350093 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11237442563b422ffe8ee22_27940399', 'navbut4');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_90993032763b422ffe90403_24256090', 'navlog');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_87446001863b422ffe9bc22_03984202', 'sidecont');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_213623117163b422ffe9e8a8_41099034', 'maincontent1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_122607943863b422ffeb6638_12948130', 'maincontent2');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_86665924163b422ffeb7456_07923652', 'maincontent3');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "sketch.tpl");
}
/* {block 'navbut4'} */
class Block_11237442563b422ffe8ee22_27940399 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut4' => 
  array (
    0 => 'Block_11237442563b422ffe8ee22_27940399',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<a class="w3-bar-item w3-hide-small w3-hide-medium w3-display-middle">Ekran logowania</a>
<?php
}
}
/* {/block 'navbut4'} */
/* {block 'navlog'} */
class Block_90993032763b422ffe90403_24256090 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navlog' => 
  array (
    0 => 'Block_90993032763b422ffe90403_24256090',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
hello" class="w3-bar-item w3-button w3-hover-white w3-display-right">Strona główna</a>
<?php
}
}
/* {/block 'navlog'} */
/* {block 'sidecont'} */
class Block_87446001863b422ffe9bc22_03984202 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidecont' => 
  array (
    0 => 'Block_87446001863b422ffe9bc22_03984202',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'sidecont'} */
/* {block 'maincontent1'} */
class Block_213623117163b422ffe9e8a8_41099034 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_213623117163b422ffe9e8a8_41099034',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['success']))) {?>
    <div class="w3-panel w3-pale-green w3-round">
    <p><?php echo $_SESSION['success'];?>
</p>
    </div>
<?php }?>
   
    <h4 class="w3-bar-item w3-text-theme"><b>Rejestracja konta</b></h4>
    <a class="w3-brown w3-button w3-round-xxlarge" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
registerView">Rejestruj konto</a>
    <br>

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
    <div class="w3-panel w3-pale-yellow w3-round">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
        <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
<?php }?>
    <h4 class="w3-bar-item w3-text-theme"><b>Logowanie</b></h4>
    <form class="" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
login" method="post">
    <label for="uname" class="w3-text-theme">login: </label>
    <input class="w3-input" id="uname" type="text" name="uname" value="<?php echo $_smarty_tpl->tpl_vars['uname']->value;?>
"/>
    <label for="psw" class="w3-text-theme">hasło: </label>
    <input class="w3-input" id="psw" type="password" name="psw" /><br />
    <div class="">
            <input type="submit" value="Zaloguj się" class="w3-brown w3-button w3-round-xxlarge"/>
    </div>
    </form>
<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_122607943863b422ffeb6638_12948130 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_122607943863b422ffeb6638_12948130',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent2'} */
/* {block 'maincontent3'} */
class Block_86665924163b422ffeb7456_07923652 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent3' => 
  array (
    0 => 'Block_86665924163b422ffeb7456_07923652',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent3'} */
}
