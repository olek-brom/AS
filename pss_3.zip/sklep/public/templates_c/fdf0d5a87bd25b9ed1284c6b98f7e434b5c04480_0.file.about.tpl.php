<?php
/* Smarty version 4.1.0, created on 2022-12-28 20:49:00
  from 'C:\xampp\htdocs\sklep\app\views\about.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63ac9daccbd7a8_90211893',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fdf0d5a87bd25b9ed1284c6b98f7e434b5c04480' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\about.tpl',
      1 => 1672256860,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ac9daccbd7a8_90211893 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_40666992663ac9daccbc492_20814356', 'maincontent1');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'maincontent1'} */
class Block_40666992663ac9daccbc492_20814356 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_40666992663ac9daccbc492_20814356',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="about-section w3-theme-l2">
      <h1>O nas</h1>
      <p>Tekst o nas, kim jesteśmy</p>
    </div>

    <h2 class="w3-text-theme" style="text-align:center">Nasz zespół</h2>
    <div class="row">
      <div class="column">
        <div class="card">
          <img src="..\app\img\team\jkowalski.png" alt="Jan Kowalski" style="width:80%">
          <div class="container">
            <h2 class="w3-text-theme">Jan Kowalski</h2>
            <p class="title">Kierownik</p>
            <p>Opis Jana Kowalskiego</p>
            <p>jan.kowalski@hair.pl</p>
            <p><a href="mailto:jan.kowalski@hair.pl" class="button w3-theme-l2">Wyślij e-mail</a></p>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <img src="..\app\img\team\anowak.png" alt="Adam Nowak" style="width:80%">
          <div class="container">
            <h2 class="w3-text-theme">Adam Nowak</h2>
            <p class="title">Kierownik</p>
            <p>Opis Adama Nowaka</p>
            <p>adam.nowak@hair.pl</p>
            <p><a href="mailto:adam.nowak@hair.pl" class="button w3-theme-l2">Wyślij e-mail</a></p>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <img src="..\app\img\team\mwisniewski.png" alt="Marek Wiśniewski" style="width:80%">
          <div class="container">
            <h2 class="w3-text-theme">Marek Wiśniewski</h2>
            <p class="title">Kierownik</p>
            <p>Opis Marka Wiśniewskiego</p>
            <p>marek.wisniewski@hair.pl</p>
            <p><a href="mailto:marek.wisniewski@hair.pl" class="button w3-theme-l2">Wyślij e-mail</a></p>
          </div>
        </div>
      </div>
    </div>
<?php
}
}
/* {/block 'maincontent1'} */
}
