<?php
/* Smarty version 4.1.0, created on 2023-01-12 10:32:25
  from 'C:\xampp\htdocs\sklep\app\views\addProduct.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63bfd3a988d7d3_07345031',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2df89bc8d0e27718af2297d6cd93fff064b3696f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\addProduct.tpl',
      1 => 1672866884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bfd3a988d7d3_07345031 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_166723903663bfd3a9865860_60677149', 'maincontent1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_46950843963bfd3a988c9e7_99592597', 'maincontent2');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "seller.tpl");
}
/* {block 'maincontent1'} */
class Block_166723903663bfd3a9865860_60677149 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_166723903663bfd3a9865860_60677149',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div class="w3-panel w3-pale-yellow w3-round">
            <p>Błąd:</p><br>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
            <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>    
    <?php }?>
    
    <h4 class="w3-bar-item w3-text-theme"><b>Utworzenie produktu</b></h4>
    <form class="w3-container" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
addProduct" method="post" id="form">
    <label for="nazwa_produktu">nazwa produktu: </label>
    <input class="w3-input" id="nazwa_produktu" placeholder="wprowadź nazwę produktu" type="text" name="nazwa_produktu"  required/>
    <label for="opis">opis: </label>
    <input class="w3-input" id="opis" placeholder="wprowadź opis produktu" type="text" name="opis"  required/><br />
    <label for="cena_brutto_dla_klienta">cena brutto dla Klienta: </label>
    <input class="w3-input" id="cena_brutto_dla_klienta" placeholder="wprowadź cenę brutto dla klienta" type="number" step="0.01" name="cena_brutto_dla_klienta"  required /><br />
    <label for="kategoria">kategoria: </label>
    <select class="w3-select" name="id_kategorii" id="id_kategorii" form="form">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['kategorie']->value, 'kategoria');
$_smarty_tpl->tpl_vars['kategoria']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['kategoria']->value) {
$_smarty_tpl->tpl_vars['kategoria']->do_else = false;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['kategoria']->value["id_kategorii"];?>
"><?php echo $_smarty_tpl->tpl_vars['kategoria']->value["nazwa_kategorii"];?>
</option>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </select>    
    <label for="sciezka_plik">nazwa pliku ze zdjęciem: </label>
    <input class="w3-input" id="sciezka_plik" placeholder="wprowadź nazwę pliku ze zdjęciem" type="text" name="sciezka_plik"  required/><br />
    <div class="">
            <input type="submit" value="Twórz Produkt" class="w3-brown w3-button w3-round-xxlarge"/>
    </div>
</form>

<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_46950843963bfd3a988c9e7_99592597 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_46950843963bfd3a988c9e7_99592597',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent2'} */
}
