<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\Validator;
use app\forms\UserForm;

class UsersEditCtrl {
    
    private $form;
    private $formSave;
    public function __construct() {
        $this->form = new UserForm();
        $this->formSave = new UserForm();
    }

    private $records; //rekordy pobrane z bazy danych
    private $record; //rekord do edycji
    private $role; //rola rekord do edycji
    private $roles; //rola rekord do edycji
        
    public function action_viewUsers() {
        try{
            $this->records = App::getDB()->select("rola_has_user", 
                    [
                       "[>]user" => ["user_id_usera" => "id_usera"] ,
                       "[>]rola" => ["rola_id_rola" => "id_rola"] 
                    ],
                    "*"
                    );
        } catch (PDOException $e){
            Utils::addErrorMessage("Problem z pobraniem użutkowników");
        }	
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        unset($_SESSION["update"]);
        
    }
    public function action_addUserView() {
        App::getSmarty()->display("addUser.tpl");
    }
    
    public function action_addUser(){
        if ($this->validateAdd()){
            App::getDB()->insert("user", [
            "haslo" => password_hash($this->form->psw, PASSWORD_DEFAULT),
            "nazwa_usera" => $this->form->uname,
            "imie" => $this->form->name,
            "nazwisko" => $this->form->surname,
            "e-mail" => $this->form->email,
            "adres" => $this->form->address,
            "kto_zalozyl_user_id" => 1,
            "kto_modyfikowal_id_usera" => 1 
            ]);
            $this->form->id = App::getDB()->id();
            App::getDB()->insert("rola_has_user", [
            "rola_id_rola" => 3,
            "user_id_usera" => $this->form->id, 
            "aktywna" => 1,
            ]);
            App::getRouter()->redirectTo('userView');
            } else {
            //niezarejestrowany => pozostań na stronie rejestracji
            $this->action_addUserView(); 
        }		
    }
    
    public function validateAdd(){
        //1. pobranie parametrów formularza rejestracji
        $v = new Validator();
        $this->form->uname = $v->validateFromPost("uname", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj login',
        'validator_message' => 'Niepoprawny login',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->psw = $v->validateFromPost("psw", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj hasło',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->pswRepeat = $v->validateFromPost("psw-repeat", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj powtórzone hasło',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->name = $v->validateFromPost("name", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj imię',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->surname = $v->validateFromPost("surname", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj nazwisko',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->email = $v->validateFromPost("email", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj email',
        'email' => true,
        ]);
        $this->form->address = $v->validateFromPost("address", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj email',
        ]);
        if (!$v->isLastOK()) return false;
        $user = App::getDB()->get("user", "*",[
        "nazwa_usera" => $this->form->uname,
        ]);
        if($user) {
            Utils::addErrorMessage("Użytkownik o podanym loginie już istnieje");
            return false;
        }
        $user = App::getDB()->get("user", "*",[
        "e-mail" => $this->form->email,
        ]);
        if($user) {
            Utils::addErrorMessage("Użytkownik o podanym adresie e-mail już istnieje");
            return false;
        }
        if($this->form->psw != $this->form->pswRepeat){
            Utils::addErrorMessage("podane hasła nie zgadzają się");
            return false;
        }
        return true;
}
    
    public function action_editUser() {
        if ( $this->validateEdit() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $this->record = App::getDB()->get("user", "*",[
                        "id_usera" => $this->form->id
                ]);
                $this->role = App::getDB()->get("rola_has_user",[
                "[>]rola" => ["rola_id_rola" => "id_rola"]
                ], "*",[
                        "user_id_usera" => $this->form->id
                ]);
                $this->roles = App::getDB()->select("rola", "*",[
                "nazwa_rola[!]" => $this->role
                ]);
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');			
        }
        App::getSmarty()->assign("record", $this->record);  // lista rekordów z bazy danych
        App::getSmarty()->assign("role", $this->role);
        App::getSmarty()->assign("roles", $this->roles);
        App::getSmarty()->display("editUser.tpl");        
        }
        else {
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        }

    }
    
    
    
    public function action_deleteUser() {
        if ( $this->validateEdit() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
//            DELETE FROM rola_has_user WHERE `rola_has_user`.`rola_id_rola` = 3 AND `rola_has_user`.`user_id_usera` = 23
                App::getDB()->delete("rola_has_user", [
                    "user_id_usera" => $this->form->id
                ]);

                App::getDB()->query(
                "UPDATE <user> SET <kto_zalozyl_user_id> = 1, <kto_modyfikowal_id_usera> = 1 WHERE <id_usera> = :kto", [
                    ":kto" => $this->form->id,
                ]);
                App::getDB()->delete("user", [
                    "id_usera" => $this->form->id
                ]);
                
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());	
                }
        }
        App::getRouter()->forwardTo('viewUsers');    
        }
        else {
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        }
    }
    
    //validacja danych przed wyswietleniem do edycji
    public function validateEdit() {
            $v = new Validator();
            $this->form->id = $v->validateFromCleanURL(1);
            if (!$v->isLastOK()) {
                return false;
            }
        return true;
    }
    
    public function action_saveUser(){
        if ( $this->validateSave() ){
        try {
                App::getDB()->update("user", [
                    "nazwa_usera" => $this->formSave->uname,
                    "e-mail" => $this->formSave->email,
                    "imie" => $this->formSave->name,
                    "nazwisko" => $this->formSave->surname,
                ], [
                        "id_usera" => $this->formSave->id,
                ]);
                App::getDB()->update("rola_has_user", [
                    "rola_id_rola" => $this->formSave->id_roli,
                ], [
                    "user_id_usera" => $this->formSave->id,
                ]);
                $_SESSION["update"] = "Pomyślnie zaktualizowano dane Użytkownika";
                App::getRouter()->redirectTo('viewUsers');
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas zapisu rekordu');			
        }
        }
        else {
        $this->role = App::getDB()->get("rola_has_user",[
        "[>]rola" => ["rola_id_rola" => "id_rola"]
        ], "*",[
        "user_id_usera" => $this->formSave->id
        ]);
        $this->roles = App::getDB()->select("rola", "*",[
        "nazwa_rola[!]" => $this->role
        ]);
        $this->record = App::getDB()->get("user", "*",[
        "id_usera" => $this->formSave->id
        ]);
        App::getSmarty()->assign("role", $this->role);
        App::getSmarty()->assign("roles", $this->roles);
        App::getSmarty()->assign('record',$this->record);  // lista rekordów z bazy danych
        App::getSmarty()->display("editUser.tpl");
        }

    }
    
    public function validateSave(){
                //1. pobranie parametrów formularza rejestracji
                $v = new Validator();
                $this->formSave->id = $v->validateFromPost("id", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj id',
                'validator_message' => 'Niepoprawny id',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->uname = $v->validateFromPost("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->email = $v->validateFromPost("email", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                'email' => true,
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->name = $v->validateFromPost("name", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj imię',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->surname = $v->validateFromPost("surname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj nazwisko',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->id_roli = $v->validateFromPost("id_roli", [
                'int' => true,
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj rolę',
                ]);
                if (!$v->isLastOK()) return false;
                return true;
    }
    
}
