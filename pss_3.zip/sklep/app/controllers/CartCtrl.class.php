<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\Validator;
use app\forms\ProductForm;

class CartCtrl {
    
    private $form;
    
    public function __construct() {
        $this->form = new ProductForm();
    }

    private $records; //rekordy pobrane z bazy danych
    private $egzemplarz; //egzemplarz rekord do edycji
        
    public function action_cartView() {
            $id_zamowienia = App::getDB()->get("zamowienie","id_zamowienia", ["AND" =>["user_id_usera" => $_SESSION["id_usera"], "czy_oplacono" => null]]);
            try{
                $this->records = App::getDB()->select("egzemplarz", 
                        [
                           "[>]zamowienie" => ["zamowienie_id_zamowienia" => "id_zamowienia"] ,
                           "[>]produkt" => ["produkt_id_produkt" => "id_produkt"] ,
                        ],
                        "*",
                        [
                        "AND" => [
                            "id_zamowienia" => "$id_zamowienia",
                        ]
                        ]
                        );
            } catch (PDOException $e){
                Utils::addErrorMessage("Problem z pobraniem produktów z bazy");
            }	
            
            $suma = 0;
            foreach ($this->records as $record){$suma += $record["cena_brutto_dla_klienta"];}
            App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
            App::getSmarty()->assign('suma',$suma);  // lista rekordów z bazy danych
            App::getSmarty()->display("viewCart.tpl");
    }
    
    public function action_confirmCart() {
        App::getDB()->update("zamowienie", [
	'data_zlozenia_zamowienia' => App::getDB()->raw('NOW()'),
        "czy_oplacono" => "1",
        ], [
        "AND"=>[
	"czy_oplacono" => null,
        "user_id_usera" => $_SESSION["id_usera"]
            ]
        ]);
        App::getRouter()->redirectTo("cartView");
    }
    
    public function action_ordersView() {
        $this->records = App::getDB()->select("zamowienie","*", [
        "user_id_usera" => $_SESSION["id_usera"]
        ]);
        App::getSmarty()->assign('records',$this->records);       
        App::getSmarty()->display("viewOrders.tpl");
    }

    public function action_deleteProductFromCart() {
        if ( $this->validateEdit() ){
        try {
                App::getDB()->delete("egzemplarz", [
                        "AND" => [
                            "produkt_id_produkt" => $this->form->id_produkt,
                            "id_egzemplarza" => $this->egzemplarz
                        ]
                ]);            
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());	
                }
        }
        App::getRouter()->redirectTo("cartView");
        }
        else {
        Utils::addErrorMessage("Problem z usunięciem z koszyka");
        App::getRouter()->redirectTo("cartView");
        }
    }
    
    public function validateEdit() {
            $v = new Validator();
            $this->form->id_produkt = $v->validateFromCleanURL(1);
            if (!$v->isLastOK()) {
                return false;
            }
            $this->egzemplarz = $v->validateFromCleanURL(2);
            if (!$v->isLastOK()) {
                return false;
            }
        return true;
        }
    
}
