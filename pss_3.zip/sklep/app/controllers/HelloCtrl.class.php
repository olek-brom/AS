<?php

namespace app\controllers;

use core\App;
use core\RoleUtils;

class HelloCtrl {
    
    public function action_hello() {
        if (RoleUtils::inRole("administrator")) {
            $this->action_hello_admin();
        }
        else if (RoleUtils::inRole("pracownik")) {
            $this->action_hello_seller();
        }
    else {
        $this->prepareView();
        App::getSmarty()->display("main.tpl");
    }
    }
    public function action_hello_admin() {
        App::getSmarty()->display("admin.tpl");
        
    }
    public function action_hello_seller() {
        App::getSmarty()->display("seller.tpl");
        
    }
        public function action_about() {
        $this->prepareView();
        App::getSmarty()->display("about.tpl");
        
    }
        private function prepareView(){
            $kategorie = App::getDB()->select("kategoria", "*");
            App::getSmarty()->assign("kategorie",$kategorie);
        }
    
}
