<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */
namespace app\forms;
/**
 * Description of UserForm
 *
 * @author Olek
 */
class UserForm {
        public $id;
        public $uname;
        public $psw;
        public $pswRepeat;
        public $name;
        public $surname;
        public $email;
        public $address;
        public $nazwa_roli;
        public $id_roli;
}
