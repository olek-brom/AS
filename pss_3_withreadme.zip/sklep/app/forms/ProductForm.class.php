<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */
namespace app\forms;
/**
 * Description of UserForm
 *
 * @author Olek
 */
class ProductForm {
        public $id_produkt;
        public $nazwa_produktu;
        public $opis;
        public $cena_brutto_dla_klienta;
        public $kategoria_id_kategorii;
        public $sciezka_plik;
}
