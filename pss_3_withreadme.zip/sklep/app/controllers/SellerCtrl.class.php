<?php

namespace app\controllers;
use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ProductForm;

class SellerCtrl {
    
    private $form;
    private $formSave;
    public function __construct() {
        $this->form = new ProductForm();
        $this->formSave = new ProductForm();
    }
    
    private $page; /// numer strony wyszukiwania DODANE
    private $per_page = 2; /// ilosc rekordow na stronie DODANE
    private $count;
    private $count_filter;

    private $records; //rekordy pobrane z bazy danych
    private $record; //rekord do edycji
    private $kategoria; //kategoria rekord do edycji
    private $kategorie; //kategorie do edycji
    private $zdjecie; //zdjecie rekord do edycji
        
    public function action_viewProducts() {
            $this->validateSearch();
            
//            $search_params = [];
//            if (isset($this->form->nazwa_produktu) && strlen($this->form->nazwa_produktu) > 0) {
//                $search_params['nazwa_produktu[~]'] = $this->form->nazwa_produktu . '%'; // dodanie symbolu % zastępuje dowolny ciąg znaków na końcu
//            }
//            $num_params = sizeof($search_params);
//            if ($num_params > 1) {
//                $where = ["AND" => &$search_params];
//            } else {
//                $where = &$search_params;
//            }
//            $where ["ORDER"] = "nazwa_produktu";
            
            if (!isset($this->page)) {$this->page = 1;}
            if ($this->page == 0) {$this->page = 1;}

            
            try{
                $this->count = App::getDB()->count("produkt");
                $this->count_filter = App::getDB()->count("produkt",
                        [
                        'nazwa_produktu[~]' => $this->form->nazwa_produktu.'%',
                        ]);
                $this->records = App::getDB()->select("produkt", 
                        [
                           "[>]kategoria" => ["kategoria_id_kategorii" => "id_kategorii"] ,
                        ],
                        "*",
                        [
                        'nazwa_produktu[~]' => $this->form->nazwa_produktu.'%',
                        'LIMIT' => [$this->per_page*($this->page-1), $this->per_page]
                        ],
                        //$where
                        );
            } catch (PDOException $e){
                Utils::addErrorMessage("Problem z pobraniem produktów z bazy");
            }	
            App::getSmarty()->assign('searchForm',$this->form);
            App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
            App::getSmarty()->assign('page',$this->page);
            App::getSmarty()->assign('count',$this->count);
            App::getSmarty()->assign('count_filter',$this->count_filter);
            App::getSmarty()->assign('per_page',$this->per_page);
            App::getSmarty()->display("viewProducts.tpl");
            unset($_SESSION["update"]);
        }
    
    public function validateSearch() {
            $v = new Validator();
            $this->form->nazwa_produktu = $v->validateFromRequest("sf_nazwa_produktu");
            if (!$v->isLastOK()) {
                return false;
            }
            $this->page = $v->validateFromRequest("page"); /// pobiera strony wyszukiwania DODANE
            if (!$v->isLastOK()) {
                return false;
            }
        return true;
    }
    
    public function action_addProductView() {
        App::getSmarty()->display("addProduct.tpl");
    }
    
    public function action_addProduct(){
        if ($this->validateAdd()){
            App::getDB()->insert("produkt", [
            "nazwa_produktu" => $this->form->nazwa_produktu,
            "opis" => $this->form->opis,
            "kategoria_id_kategorii" => $this->form->kategoria_id_kategorii,
            "cena_brutto_dla_klienta" => $this->form->cena_brutto_dla_klienta,
            ]);
            $this->form->id_produkt = App::getDB()->id();
            $sciezka = '..\app\img\\';
            App::getDB()->insert("zdjecie", [
            "sciezka_plik" => $sciezka.($this->form->sciezka_plik),
            "id_produkt" => $this->form->id_produkt, 
            ]);
            App::getRouter()->redirectTo("viewProducts");
            } else {
            //niezarejestrowany => pozostań na stronie rejestracji
            $this->action_addProductView(); 
        }		
    }
    
    public function validateAdd(){
        //1. pobranie parametrów formularza rejestracji
        $v = new Validator();
        $this->form->nazwa_produktu = $v->validateFromPost("nazwa_produktu", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj nazwę',
        'validator_message' => 'Niepoprawna nazwa',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->opis = $v->validateFromPost("opis", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj opis',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->cena_brutto_dla_klienta = $v->validateFromPost("cena_brutto_dla_klienta", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj cenę',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->kategoria_id_kategorii = $v->validateFromPost("id_kategorii", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj kategorię',
        ]);
        if (!$v->isLastOK()) return false;
        $this->form->sciezka_plik = $v->validateFromPost("sciezka_plik", [
        'trim' => true,
        'required' => true,
        'required_message' => 'Podaj ścieżkę',
        ]);
        if (!$v->isLastOK()) return false;
        $produkt = App::getDB()->get("produkt", "*",[
        "nazwa_produktu" => $this->form->nazwa_produktu,
        ]);
        if($produkt) {
            Utils::addErrorMessage("Produkt o podanej nazwie już istnieje");
            return false;
        }
        return true;
}
    
    public function action_editProduct() {
        if ( $this->validateEdit() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $this->record = App::getDB()->get("produkt", "*",[
                        "id_produkt" => $this->form->id_produkt
                ]);
                $this->kategoria = App::getDB()->get("kategoria",[
                "[>]produkt" => ["id_kategorii" => "kategoria_id_kategorii"]
                ], "*",[
                        "id_produkt" => $this->form->id_produkt
                ]);
                $this->kategorie = App::getDB()->select("kategoria", "*",[
                "nazwa_kategorii[!]" => $this->kategoria
                ]);
                $full = App::getDB()->get("zdjecie",[
                "[>]produkt" => ["produkt_id_produkt" => "id_produkt"]
                ], "sciezka_plik",[
                        "id_produkt" => $this->form->id_produkt
                ]);
                $pieces = explode("\\", $full);
                $this->zdjecie = $pieces[3];
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');			
        }
        App::getSmarty()->assign("record", $this->record);  // lista rekordów z bazy danych
        App::getSmarty()->assign("kategoria", $this->kategoria);
        App::getSmarty()->assign("kategorie", $this->kategorie);
        App::getSmarty()->assign("zdjecie", $this->zdjecie);
        App::getSmarty()->display("editProduct.tpl");        
        }
        else {
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewProducts.tpl");
        }

    }
    
    
    
    public function action_deleteProduct() {
        if ( $this->validateEdit() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
//            DELETE FROM rola_has_user WHERE `rola_has_user`.`rola_id_rola` = 3 AND `rola_has_user`.`user_id_usera` = 23
                App::getDB()->delete("zdjecie", [
                    "id_produkt" => $this->form->id_produkt
                ]);

                App::getDB()->delete("produkt", [
                    "id_produkt" => $this->form->id_produkt
                ]);
                
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());	
                }
        }
        App::getRouter()->forwardTo('viewProducts');    
        }
        else {
            //validateedit nie zwraca obecnie false
        }
    }
    
    //validacja danych przed wyswietleniem do edycji
    public function validateEdit() {
            //pobierz parametry na potrzeby wyswietlenia danych do edycji
            //z widoku listy osób (parametr jest wymagany)
            $v = new Validator();
            $this->form->id_produkt = $v->validateFromCleanURL(1);
            if (!$v->isLastOK()) {
                return false;
            }
        return true;
    }
    
    public function action_saveProduct(){
        if ( $this->validateSave() ){
        try {
                App::getDB()->update("produkt", [
                    "cena_brutto_dla_klienta" => $this->formSave->cena_brutto_dla_klienta,
                    "kategoria_id_kategorii" => $this->formSave->kategoria_id_kategorii,
                    "nazwa_produktu" => $this->formSave->nazwa_produktu,
                    "opis" => $this->formSave->opis,
                ], [
                        "id_produkt" => $this->formSave->id_produkt,
                ]);
                $sciezka = '..\app\img\\';
                App::getDB()->update("zdjecie", [
                    "sciezka_plik" => $sciezka.$this->formSave->sciezka_plik,
                ], [
                    "produkt_id_produkt" => $this->formSave->id_produkt,
                ]);
//                $query = App::getDB()->query(
//                "UPDATE <user> SET <nazwa_usera> = :uname, <e-mail> = :email, <imie> = :name, <nazwisko> = :surname WHERE <id_usera> = :id", [
//                    ":id" => $this->formSave->id,
//                    ":uname" => $this->formSave->uname,
//                    ":email" => $this->formSave->email,
//                    ":name" => $this->formSave->surname,
//                    ":surname" => $this->formSave->name,
//                ]);
                $_SESSION["update"] = "Pomyślnie zaktualizowano dane produktu";
                App::getRouter()->redirectTo('viewProducts');
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas zapisu rekordu');			
        }
        }
        else {
            Utils::addErrorMessage('Wystąpił błąd podczas zapisu rekordu');	
            //App::getRouter()->redirectTo('viewProducts');
        }

    }
        
    public function validateSave(){
                //1. pobranie parametrów formularza rejestracji
                $v = new Validator();
                $this->formSave->id_produkt = $v->validateFromPost("id_produkt", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj id',
                'validator_message' => 'Niepoprawny id',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->nazwa_produktu = $v->validateFromPost("nazwa_produktu", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj nazwę',
                'validator_message' => 'Niepoprawna nazwa',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->opis = $v->validateFromPost("opis", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj opis',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->cena_brutto_dla_klienta = $v->validateFromPost("cena_brutto_dla_klienta", [
                'float' => true,
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj cenę',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->kategoria_id_kategorii = $v->validateFromPost("id_kategorii", [
                'int' => true,
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj kategorię',
                ]);
                if (!$v->isLastOK()) return false;
                $this->formSave->sciezka_plik = $v->validateFromPost("sciezka_plik", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj scieżkę do pliku ze zdjęciem',
                ]);
                if (!$v->isLastOK()) return false;
                return true;
    }
    
    
        public function action_viewConfirmedCarts() {
            
            //wykonanie zapytania
            try{
                $this->records = App::getDB()->select("zamowienie", 
                        [
                           "[>]user" => ["user_id_usera" => "id_usera"]
                        ],
                        "*",
                        ["czy_oplacono" => 1, "czy_wyslano" => 0],
                        );
            } catch (PDOException $e){
                Utils::addErrorMessage("Problem z pobraniem zamowien z bazy");
            }	

            App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
            App::getSmarty()->display("viewconfirmedCarts.tpl");
        }
        
            public function action_viewConfirmedCartsDetails() {
            $id_zamowienia = ParamUtils::getFromCleanURL(1);
            //wykonanie zapytania
            try{
                $this->records = App::getDB()->select("zamowienie", 
                        [
                           "[>]user" => ["user_id_usera" => "id_usera"],
                           "[>]egzemplarz" => ["id_zamowienia" => "zamowienie_id_zamowienia"],
                           "[>]produkt" => ["egzemplarz.produkt_id_produkt" => "id_produkt"]
                        ],
                        "*",
                        ["id_zamowienia" => $id_zamowienia,],
                        );
            } catch (PDOException $e){
                Utils::addErrorMessage("Problem z pobraniem zamowien z bazy");
            }	

            App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
            App::getSmarty()->display("viewconfirmedCartsDetails.tpl");
        }
            public function action_sendCart() {
            $id_zamowienia = ParamUtils::getFromCleanURL(1);
            //wykonanie zapytania
            try{
                $this->records = App::getDB()->update("zamowienie",
                        ["czy_wyslano" => 1,'data_zrealizowania_zamowienia' => App::getDB()->raw('NOW()'),'data_wysylki' => App::getDB()->raw('NOW()')],
                        ["id_zamowienia" => $id_zamowienia,],
                        );
            } catch (PDOException $e){
                Utils::addErrorMessage("Problem z pobraniem zamowien z bazy");
            }	
            App::getRouter()->redirectTo('viewConfirmedCarts');
        }
}
