<?php
namespace app\controllers;

use core\Validator;
use core\App;
use core\Utils;
use app\forms;

/**
 * Description of LoginCtrl
 *
 * @author Olek
 */
class LoginCtrl {	
        private $form;

        public function __construct() {
            $this->form = new UserForm();
        }
        public $id;
        public $uname = "";
        public $psw = "";
        public $pswRepeat = "";
        public $name = "";
        public $surname = "";
        public $email = "";
        public $address = "";
        public $nazwa_roli = "";
        
	public function validate() {
                //1. pobranie parametrów formularza logowania (login i hasło)
                $v = new Validator();
                $this->uname = $v->validateFromRequest("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->psw = $v->validateFromRequest("psw", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj hasło',
                ]);
                if (!$v->isLastOK()) return false;
                
                $user = App::getDB()->get("user", "*",[
                "nazwa_usera" => $this->uname,
//                "haslo" => password_hash($this->psw, PASSWORD_DEFAULT),
                ]);
                if(!$user) {
                    Utils::addErrorMessage("Użytkownik o podanym loginie nie istnieje");
                    return false;
                }
                if (!password_verify($this->psw, $user['haslo'])) {
                    Utils::addErrorMessage("Niepoprawne hasło");
                    return false;
                }
                $role = App::getDB()->select("rola_has_user", "*",[
                "user_id_usera" => $user["id_usera"],
                ]);

//                if (!($user["nazwa_usera"] == $this->uname && $user['haslo'] == $this->psw)) {
//                    Utils::addErrorMessage("Niepoprawne hasło");
//                    return false;
//                }

                foreach($role as $rola) {
                    $this->nazwa_roli = App::getDB()->get("rola", "nazwa_rola",[
                    "id_rola" => $rola["rola_id_rola"],
                    ]);
                    \core\RoleUtils::addRole($this->nazwa_roli);//rola["rola_id_rola"]); //zapisanie roli w sesji
                }
                $_SESSION["user"] = $user["imie"]." ".$user["nazwisko"]." ".$this->nazwa_roli;
                return true;

	}
        
        public function validateRegister(){
                //1. pobranie parametrów formularza rejestracji
                $v = new Validator();
                $this->uname = $v->validateFromPost("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->psw = $v->validateFromPost("psw", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->pswRepeat = $v->validateFromPost("psw-repeat", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj powtórzone hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->name = $v->validateFromPost("name", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj imię',
                ]);
                if (!$v->isLastOK()) return false;
                $this->surname = $v->validateFromPost("surname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj nazwisko',
                ]);
                if (!$v->isLastOK()) return false;
                $this->email = $v->validateFromPost("email", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                'email' => true,
                ]);
                $this->address = $v->validateFromPost("address", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                ]);
                if (!$v->isLastOK()) return false;
                $user = App::getDB()->get("user", "*",[
                "nazwa_usera" => $this->uname,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym loginie już istnieje");
                    return false;
                }
                $user = App::getDB()->get("user", "*",[
                "e-mail" => $this->email,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym adresie e-mail już istnieje");
                    return false;
                }
                if($this->psw != $this->pswRepeat){
                    Utils::addErrorMessage("podane hasła nie zgadzają się");
                    return false;
                }
                return true;
        }

	public function action_loginView(){
		$this->generateView(); 
	}
        
        public function action_registerView(){
		$this->generateRegisterView(); 
	}
	
	public function action_login(){
		if ($this->validate()){
			//zalogowany => przekieruj na główną akcję (z przekazaniem messages przez sesję)
                    if ($this->nazwa_roli != "administrator") {
                        App::getRouter()->redirectTo("hello");
                    }
                    if ($this->nazwa_roli == "administrator") {
                        App::getRouter()->redirectTo("hello_admin");
                    }
                } else {
			//niezalogowany => pozostań na stronie logowania
			$this->generateView(); 
		}		
	}
	
	public function action_logout(){
		// 1. zakończenie sesji
		session_destroy();
		// 2. idź na stronę główną - system automatycznie przekieruje do strony logowania
		App::getRouter()->redirectTo('hello');
	}	

//Pełne teksty
//id_usera	
//haslo	
//kto_zalozyl_user_id	
//nazwa_usera	
//data_zalozenia	
//imie	
//nazwisko	
//e-mail	
//adres	
//kiedy_modyfikowal	
//kto_modyfikowal_id_usera        
	public function action_register(){
            if ($this->validateRegister()){
                App::getDB()->insert("user", [
                "haslo" => password_hash($this->psw, PASSWORD_DEFAULT),
                "nazwa_usera" => $this->uname,
                "imie" => $this->name,
                "nazwisko" => $this->surname,
                "e-mail" => $this->email,
                "adres" => $this->address,
                "kto_zalozyl_user_id" => 1,
                "kto_modyfikowal_id_usera" => 1 
                ]);
                $this->id = App::getDB()->id();
                App::getDB()->query(
                "UPDATE <user> SET <kto_zalozyl_user_id> = :kto, <kto_modyfikowal_id_usera> = :kto WHERE <id_usera> = :kto", [
                    ":kto" => $this->id,
                ]);
//                App::getDB()->update("user", [
//                    "kto_zalozyl_user_id[+]" => 1,
//                    "kto_modyfikowal_id_usera[+]" => 1,
//                ], [
//                    "nazwa_usera" => $this->id,
//                ]);
                App::getDB()->insert("rola_has_user", [
                "rola_id_rola" => 3,
                "user_id_usera" => $this->id, 
                "aktywna" => 1,
                ]);
                $_SESSION["success"] = "Rejestracja powiodła się";
                App::getRouter()->redirectTo('loginView');
                } else {
                //niezarejestrowany => pozostań na stronie rejestracji
                $this->generateRegisterView(); 
            }		
	}
	
	public function generateView(){
		App::getSmarty()->assign('uname',$this->uname); // dane formularza do widoku
		App::getSmarty()->display('login.tpl');		
	}
        public function generateRegisterView(){
        App::getSmarty()->assign('uname',$this->uname); // dane formularza do widoku
        App::getSmarty()->assign('name',$this->name); // dane formularza do widoku
        App::getSmarty()->assign('surname',$this->surname); // dane formularza do widoku
        App::getSmarty()->assign('email',$this->email); // dane formularza do widoku
        App::getSmarty()->assign('address',$this->address); // dane formularza do widoku
        App::getSmarty()->display('register.tpl');		
	}
}

//public function action_login() {
//    //1. pobranie parametrów formularza logowania (login i hasło)
//    $v = new Validator();
//    $uname = $v->validateFromRequest("uname", [
//    'trim' => true,
//    'required' => true,
//    'email' => true,
//    'required_message' => 'Podaj login',
//    'validator_message' => 'Niepoprawny login',
//    ]);
//    $psw = $v->validateFromRequest("psw", [
//    'trim' => true,
//    'required' => true,
//    'required_message' => 'Podaj hasło',
//    ]);
//
//    //2. walidacja (pobranie z BD informacji o użytkowniku)
//    $user = App::getDB()->get("user", "*",[
//    "nazwa_usera" => $uname,
//    "haslo" => $psw
//    ]);
//    if($user){
//        $role = App::getDB()->select("rola_has_user", "*",[
//        "user_id_usera" => $user["id_usera"],
//        ]);
//
//        if ($user["nazwa_usera"] == $uname && $user['haslo'] == $psw) {
//            foreach($role as $rola) {
//                $nazwa_roli = App::getDB()->get("rola", "nazwa_rola",[
//                "id_rola" => $rola["rola_id_rola"],
//                ]);
//                \core\RoleUtils::addRole($rola["rola_id_rola"]); //zapisanie roli w sesji
//            }
//            $_SESSION["user"] = $user["imie"]." ".$user["nazwisko"]." ".$nazwa_roli;
//            App::getRouter()->redirectTo("hello");
//        }
//    }
//    //... //załóżmy, że rola użytkownika zostanie tu zapisana w zmiennej $rola
// 
//    //3.1 jeśli walidacja poprawna to "zaloguj"
//    
//    //\core\RoleUtils::addRole($rola); //zapisanie roli w sesji
//
//    // i przekieruj do wybranej akcji (tej domyślnej po zalogowaniu)
//    
//    //App::getRouter()->redirectTo("hello");
//
//    //3.2 jeśli walidacja niepoprawna to pozostań na stronie logowania i wyświetl komunikaty
//    ///...
//
// }
// 
// public function action_logout() {
//
//    //unieważnij sesję
//    session_destroy();
//
//    // i przekieruj do wybranej akcji (tej domyślnej po wylogowaniu)
//    App::getRouter()->redirectTo("hello");
//
//}
//public function action_loginView(){
//        $this->generateView(); 
//}
//public function generateView(){
//        App::getSmarty()->assign('uname',$uname); // dane formularza do widoku
//        App::getSmarty()->display('login.tpl');		
//}
//}