<?php
/* Smarty version 4.1.0, created on 2023-01-07 01:31:25
  from 'C:\xampp\htdocs\sklep\app\views\templates\sketch.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63b8bd5d59f858_39394767',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '580fba5b7f096edf64db697b4987af5e0d6d5e77' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\templates\\sketch.tpl',
      1 => 1673051376,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63b8bd5d59f858_39394767 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Hair. Akcesoria do włosów</title> <link rel="icon" type="image/x-icon" href="../app/views/templates/logo/Logo Maker/favicon_32x32.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-brown.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif;}
.w3-sidebar {
  z-index: 3;
  width: 250px;
  top: 43px;
  bottom: 0;
  height: inherit;
}
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
{*TUTAJ CSSy związane z galerią produktów*}
* {
  box-sizing: border-box;
}

/* Create three columns of equal width */
.columns {
  float: left;
  width: 33.3%;
  padding: 8px;
}

/* Style the list */
.price {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}

/* Add shadows on hover */
.price:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}

/* Pricing header */
.price .header {
  background-color: #111;
  color: white;
  font-size: 25px;
}

/* List items */
.price li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}

/* Grey list item */
.price .grey {
  background-color: #eee;
  font-size: 20px;
}

/* The "Sign Up" button */
.button {
  background-color: #04AA6D;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}

/* Change the width of the three columns to 100%
(to stack horizontally on small screens) */
@media only screen and (max-width: 600px) {
  .columns {
    width: 100%;
  }
}
{*/TUTAJ CSSy związane z galerią produktów*}
{*TUTAJ CSSy związane z kartą produktu*}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  {*color: w3-theme-l2;*}
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
{*/TUTAJ CSSy związane z kartą produktu*}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
.mySlides {display:none;}
    
</style> -->
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-theme w3-top w3-left-align w3-large">
        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
hello" class="w3-bar-item "><img src="http://localhost/sklep/app/views/templates/logo/logo.png" alt="Hair. Akcesoria do włosów" class="w3-image" style="width:100%;max-width:65px"></a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_133075093063b8bd5d588fc8_13415842', 'navbut1act');
?>
" class="w3-bar-item w3-button w3-hide-small w3-hide-medium w3-hover-white"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_59741228763b8bd5d58acc2_21739410', 'navbut1');
?>
</a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_112706541263b8bd5d58d2d1_43725991', 'navbut2act');
?>
" class="w3-bar-item w3-button w3-hide-small w3-hover-white"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_143766950963b8bd5d58e7a0_54121672', 'navbut2');
?>
</a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_117870863b8bd5d590bb0_78795955', 'navbut3act');
?>
" class="w3-bar-item w3-button w3-hover-white"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9759204363b8bd5d591f31_24313961', 'navbut3');
?>
</a>
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_139799998663b8bd5d593135_48627360', 'navbut4');
?>

    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12554663463b8bd5d5944f6_67633013', 'navlog');
?>

  </div>
</div>
<!-- Sidebar -->
<nav class="w3-sidebar w3-bar-block w3-collapse w3-large w3-theme-l5 w3-animate-left" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-right w3-xlarge w3-padding-large w3-hover-black w3-hide-large" title="Close Menu">
    <i class="fa fa-remove"></i>
  </a>
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_118969149963b8bd5d595667_14535185', 'sidecont');
?>

</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- Main content: shift it to the right by 250 pixels when the sidebar is visible -->
<div class="w3-main" style="margin-left:250px">
    
  <div class="w3-row w3-padding-64">
    <div class="w3-container">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_46552363b8bd5d596dc7_08629737', 'maincontent1');
?>

    </div>
  </div>

  <div class="w3-row w3-padding-64">
    <div class="w3-container">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_206736698663b8bd5d597de6_60611603', 'maincontent2');
?>

    </div>
  </div>

  <div class="w3-row w3-padding-64">
    <div class="w3-container">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_100934513863b8bd5d59a783_77245488', 'maincontent3');
?>

    </div>
  </div>
<!-- END MAIN -->
</div>
    
  <footer class="w3-main" style="margin-left:250px" id="myFooter">
    <div class="w3-container w3-theme-l2 w3-padding-32">
      <h4>Hair. Akcesoria do włosów</h4>
    </div>

    <div class="w3-container w3-theme-l1">
      <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
    </div>
  </footer>
<?php echo '<script'; ?>
>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
<?php echo '</script'; ?>
>

</body>
</html>
<!--
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<meta charset="utf-8"/>
	<title>Hello World | Amelia framework</title>
</head>

<body>
    
    My value: 
</body>

</html>
--><?php }
/* {block 'navbut1act'} */
class Block_133075093063b8bd5d588fc8_13415842 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1act' => 
  array (
    0 => 'Block_133075093063b8bd5d588fc8_13415842',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut1act'} */
/* {block 'navbut1'} */
class Block_59741228763b8bd5d58acc2_21739410 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1' => 
  array (
    0 => 'Block_59741228763b8bd5d58acc2_21739410',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut1'} */
/* {block 'navbut2act'} */
class Block_112706541263b8bd5d58d2d1_43725991 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2act' => 
  array (
    0 => 'Block_112706541263b8bd5d58d2d1_43725991',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut2act'} */
/* {block 'navbut2'} */
class Block_143766950963b8bd5d58e7a0_54121672 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2' => 
  array (
    0 => 'Block_143766950963b8bd5d58e7a0_54121672',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut2'} */
/* {block 'navbut3act'} */
class Block_117870863b8bd5d590bb0_78795955 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut3act' => 
  array (
    0 => 'Block_117870863b8bd5d590bb0_78795955',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut3act'} */
/* {block 'navbut3'} */
class Block_9759204363b8bd5d591f31_24313961 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut3' => 
  array (
    0 => 'Block_9759204363b8bd5d591f31_24313961',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'navbut3'} */
/* {block 'navbut4'} */
class Block_139799998663b8bd5d593135_48627360 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut4' => 
  array (
    0 => 'Block_139799998663b8bd5d593135_48627360',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <?php
}
}
/* {/block 'navbut4'} */
/* {block 'navlog'} */
class Block_12554663463b8bd5d5944f6_67633013 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navlog' => 
  array (
    0 => 'Block_12554663463b8bd5d5944f6_67633013',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <?php
}
}
/* {/block 'navlog'} */
/* {block 'sidecont'} */
class Block_118969149963b8bd5d595667_14535185 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidecont' => 
  array (
    0 => 'Block_118969149963b8bd5d595667_14535185',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        
    <?php
}
}
/* {/block 'sidecont'} */
/* {block 'maincontent1'} */
class Block_46552363b8bd5d596dc7_08629737 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_46552363b8bd5d596dc7_08629737',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        
    <?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_206736698663b8bd5d597de6_60611603 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_206736698663b8bd5d597de6_60611603',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php
}
}
/* {/block 'maincontent2'} */
/* {block 'maincontent3'} */
class Block_100934513863b8bd5d59a783_77245488 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent3' => 
  array (
    0 => 'Block_100934513863b8bd5d59a783_77245488',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php
}
}
/* {/block 'maincontent3'} */
}
