<?php
/* Smarty version 4.1.0, created on 2023-01-15 13:33:38
  from 'C:\xampp\htdocs\sklep\app\views\seller.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63c3f2a2a14a36_86390458',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75bee51691b769eccf47d3e597bd9ab555e069a7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\seller.tpl',
      1 => 1673518070,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63c3f2a2a14a36_86390458 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19658472263c3f2a26e5374_12647222', 'navbut1act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_41962940663c3f2a26ea677_12888142', 'navbut1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_91890602663c3f2a26ebea5_11979948', 'navbut2act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_170326747963c3f2a26eced3_84314260', 'navbut2');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_84854855863c3f2a26edc63_81720209', 'navbut4');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_148631831563c3f2a2861cd9_42401493', 'navlog');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_207991679063c3f2a28cc712_15819326', 'maincontent1');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "sketch.tpl");
}
/* {block 'navbut1act'} */
class Block_19658472263c3f2a26e5374_12647222 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1act' => 
  array (
    0 => 'Block_19658472263c3f2a26e5374_12647222',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

viewConfirmedCarts
<?php
}
}
/* {/block 'navbut1act'} */
/* {block 'navbut1'} */
class Block_41962940663c3f2a26ea677_12888142 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1' => 
  array (
    0 => 'Block_41962940663c3f2a26ea677_12888142',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

Zamówienia
<?php
}
}
/* {/block 'navbut1'} */
/* {block 'navbut2act'} */
class Block_91890602663c3f2a26ebea5_11979948 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2act' => 
  array (
    0 => 'Block_91890602663c3f2a26ebea5_11979948',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

viewProducts
<?php
}
}
/* {/block 'navbut2act'} */
/* {block 'navbut2'} */
class Block_170326747963c3f2a26eced3_84314260 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2' => 
  array (
    0 => 'Block_170326747963c3f2a26eced3_84314260',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

Produkty
<?php
}
}
/* {/block 'navbut2'} */
/* {block 'navbut4'} */
class Block_84854855863c3f2a26edc63_81720209 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut4' => 
  array (
    0 => 'Block_84854855863c3f2a26edc63_81720209',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a class="w3-bar-item w3-hide-small w3-hide-medium w3-display-middle">Witaj <?php echo $_SESSION['user'];?>
</a>
<?php }
}
}
/* {/block 'navbut4'} */
/* {block 'navlog'} */
class Block_148631831563c3f2a2861cd9_42401493 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navlog' => 
  array (
    0 => 'Block_148631831563c3f2a2861cd9_42401493',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout" class="w3-bar-item w3-button w3-hover-white w3-display-right">Wyloguj</a>
<?php } else { ?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
loginView" class="w3-bar-item w3-button w3-hover-white w3-display-right">Zaloguj</a>    
<?php }
}
}
/* {/block 'navlog'} */
/* {block 'maincontent1'} */
class Block_207991679063c3f2a28cc712_15819326 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_207991679063c3f2a28cc712_15819326',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
<div class="w3-panel w3-pale-yellow w3-round">
    <p>Błąd:</p><br>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
    <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div>    
<?php }?>
<div class="w3-text-theme">
    <h4 class="w3-bar-item"><b>Panel sprzedawcy</b></h4>
    <p>W panelu sprzedawcy możesz:</p>
    <div class="">
        <ul class="w3-ul">
            <li><i class="fa fa-arrow-right w3-large w3-margin"></i> Przeglądać zamówienia</li>
            <li><i class="fa fa-truck w3-large w3-margin"></i> Edytować produkty</li>
        </ul>
    </div>
</div>
<?php
}
}
/* {/block 'maincontent1'} */
}
