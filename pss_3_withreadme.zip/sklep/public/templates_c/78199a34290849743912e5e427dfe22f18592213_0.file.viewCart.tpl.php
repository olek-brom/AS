<?php
/* Smarty version 4.1.0, created on 2023-01-12 11:08:25
  from 'C:\xampp\htdocs\sklep\app\views\viewCart.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63bfdc192ebb72_97044222',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '78199a34290849743912e5e427dfe22f18592213' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\viewCart.tpl',
      1 => 1673518069,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bfdc192ebb72_97044222 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_194066585063bfdc192c4ee4_15306640', 'sidecont');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_88883463bfdc192c7e99_84057601', 'maincontent1');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_135092652363bfdc192eaf52_64917497', 'maincontent2');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'sidecont'} */
class Block_194066585063bfdc192c4ee4_15306640 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidecont' => 
  array (
    0 => 'Block_194066585063bfdc192c4ee4_15306640',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'sidecont'} */
/* {block 'maincontent1'} */
class Block_88883463bfdc192c7e99_84057601 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_88883463bfdc192c7e99_84057601',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
<div class="w3-panel w3-pale-green w3-round">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
        <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div>
<?php }?>
    
    <h4 class="w3-bar-item w3-text-theme"><b>Przegląd produktów w koszyku</b></h4>
    <div class="w3-table w3-striped">
    <table id="tab_people">
    <thead>
            <tr class="w3-brown">
                    <th>Nazwa produktu</th>
                    <th>Opis</th>
                    <th>Cena brutto</th>
                    <th>Usuń</th>
            </tr>
    </thead>
    <tbody>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['records']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
    <tr><td><?php echo $_smarty_tpl->tpl_vars['r']->value["nazwa_produktu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["opis"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena_brutto_dla_klienta"];?>
</td><td><a class="w3-button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
deleteProductFromCart/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_produkt'];?>
/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_egzemplarza'];?>
">Usuń</a></td></tr>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
    </table>
    </div>
    
    <h4 class="w3-bar-item w3-text-theme"><b>Do zapłaty <?php echo $_smarty_tpl->tpl_vars['suma']->value;?>
 PLN</b></h4> 
    
    <h4 class="w3-bar-item w3-text-theme"><b>Potwierdź zamówienie</b></h4>
    <a class="w3-brown w3-button w3-round-xxlarge" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
confirmCart">Potwierdź zamówienie</a>
    <br>
    
<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_135092652363bfdc192eaf52_64917497 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_135092652363bfdc192eaf52_64917497',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent2'} */
}
