<?php
/* Smarty version 4.1.0, created on 2023-01-15 20:09:32
  from 'C:\xampp\htdocs\sklep\app\views\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63c44f6c72aaa8_93457482',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cb2ccf04fed8b221efdf3876fbbd31313ac1792a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\main.tpl',
      1 => 1673809768,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63c44f6c72aaa8_93457482 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_178232788463c44f6c6f2cb9_26225854', 'navbut1act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_160055684263c44f6c6f4188_40181653', 'navbut1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_162169328263c44f6c6f4fa9_63373351', 'navbut2act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_195885403263c44f6c6f5cd6_23801198', 'navbut2');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_180878734763c44f6c6f6974_60862355', 'navbut3act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20129389863c44f6c6f7616_44386997', 'navbut3');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_95556487363c44f6c6f8242_68076410', 'navbut4');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_157645863063c44f6c712b88_59688399', 'navlog');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_84129878963c44f6c71af69_00001273', 'sidecont');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_133889073363c44f6c729535_10080061', 'maincontent1');
?>



<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "sketch.tpl");
}
/* {block 'navbut1act'} */
class Block_178232788463c44f6c6f2cb9_26225854 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1act' => 
  array (
    0 => 'Block_178232788463c44f6c6f2cb9_26225854',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

about
<?php
}
}
/* {/block 'navbut1act'} */
/* {block 'navbut1'} */
class Block_160055684263c44f6c6f4188_40181653 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1' => 
  array (
    0 => 'Block_160055684263c44f6c6f4188_40181653',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

O nas
<?php
}
}
/* {/block 'navbut1'} */
/* {block 'navbut2act'} */
class Block_162169328263c44f6c6f4fa9_63373351 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2act' => 
  array (
    0 => 'Block_162169328263c44f6c6f4fa9_63373351',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

ordersView
<?php
}
}
/* {/block 'navbut2act'} */
/* {block 'navbut2'} */
class Block_195885403263c44f6c6f5cd6_23801198 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2' => 
  array (
    0 => 'Block_195885403263c44f6c6f5cd6_23801198',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

Historia zamówień
<?php
}
}
/* {/block 'navbut2'} */
/* {block 'navbut3act'} */
class Block_180878734763c44f6c6f6974_60862355 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut3act' => 
  array (
    0 => 'Block_180878734763c44f6c6f6974_60862355',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

cartView
<?php
}
}
/* {/block 'navbut3act'} */
/* {block 'navbut3'} */
class Block_20129389863c44f6c6f7616_44386997 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut3' => 
  array (
    0 => 'Block_20129389863c44f6c6f7616_44386997',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

Koszyk
<?php
}
}
/* {/block 'navbut3'} */
/* {block 'navbut4'} */
class Block_95556487363c44f6c6f8242_68076410 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut4' => 
  array (
    0 => 'Block_95556487363c44f6c6f8242_68076410',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a class="w3-bar-item w3-hide-small w3-hide-medium w3-display-middle">Witaj <?php echo $_SESSION['user'];?>
</a>
<?php }
}
}
/* {/block 'navbut4'} */
/* {block 'navlog'} */
class Block_157645863063c44f6c712b88_59688399 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navlog' => 
  array (
    0 => 'Block_157645863063c44f6c712b88_59688399',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout" class="w3-bar-item w3-button w3-hover-white w3-display-right">Wyloguj</a>
<?php } else { ?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
loginView" class="w3-bar-item w3-button w3-hover-white w3-display-right">Zaloguj</a>    
<?php }
}
}
/* {/block 'navlog'} */
/* {block 'sidecont'} */
class Block_84129878963c44f6c71af69_00001273 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidecont' => 
  array (
    0 => 'Block_84129878963c44f6c71af69_00001273',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h4 class="w3-bar-item w3-text-theme"><b>Kategorie</b></h4>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['kategorie']->value, 'kategoria');
$_smarty_tpl->tpl_vars['kategoria']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['kategoria']->value) {
$_smarty_tpl->tpl_vars['kategoria']->do_else = false;
?>
    <form class="" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
productView" method="post">
        <input name="produkt" type="submit" value="<?php echo $_smarty_tpl->tpl_vars['kategoria']->value["nazwa_kategorii"];?>
" class="w3-bar-item w3-button w3-hover-brown"/>
    </form>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
/* {/block 'sidecont'} */
/* {block 'maincontent1'} */
class Block_133889073363c44f6c729535_10080061 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_133889073363c44f6c729535_10080061',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
      <h1 class="w3-text-theme">Hair.pl</h1>
      <p>//opis skopiowany z sieci// Fryzomania to sklep fryzjerski online z profesjonalnymi artykułami fryzjerskimi i kosmetycznymi. Powstał z myślą o wszystkich, którzy cenią sobie komfort i wygodę, jakie daje elektroniczna forma zakupów. Nadrzędnym celem naszej hurtowni fryzjerskiej jest pełna satysfakcja Klientów, a kluczem do jej osiągnięcia jest przede wszystkim ciągłe podnoszenie jakości i standardów obsługi. Dobry fryzjer lub klientki, które pragną w profesjonalny sposób zadbać o Swoje włosy kupują w naszym sklepie fryzjerskim - dołącz do nich już dziś a nasza internetowa hurtownia fryzjerska stanie się miejscem Twoich zakupów. Zobaczysz na jak wysokim poziomie stoi obsługa klientów i jakie mamy dla nich okazje i rabaty. Reasumując nasz sklep fryzjerski Fryzomania to gwarantowana satysfakcja i zadowolenie z zakupionych produktów. Serdecznie zapraszamy.</p>   

<?php
}
}
/* {/block 'maincontent1'} */
}
