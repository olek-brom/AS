<?php

namespace app\controllers;

use core\App;
use core\Validator;
use core\Utils;

class ProductCtrl {
    
    public function action_productView() {
        $v = new Validator();        
        $pobrana = $v->validateFromRequest("produkt");
        $id_kategorii = App::getDB()->get("kategoria", "id_kategorii",[
        "nazwa_kategorii" => $pobrana,
        ]);
        $produkty = App::getDB()->select("produkt", ["[>]zdjecie" => ["id_produkt" => "produkt_id_produkt"]], ["produkt.id_produkt","produkt.nazwa_produktu", "produkt.cena_brutto_dla_klienta","produkt.opis", "zdjecie.sciezka_plik"],[
        "kategoria_id_kategorii" => $id_kategorii,
        ]);
        $kategorie = App::getDB()->select("kategoria", "*");
        App::getSmarty()->assign("kategorie",$kategorie);  
        App::getSmarty()->assign("kategorie",$kategorie);  
        App::getSmarty()->assign("pobrana",$pobrana);  
        App::getSmarty()->assign("produkty",$produkty);  
        App::getSmarty()->display("product.tpl");
        \core\SessionUtils::store("kategoria", $pobrana);
        
    }
    public function action_addToCart(){
        $v = new Validator();  
        $product = $v->validateFromRequest("product");
        if(!$koszyk = App::getDB()->get("zamowienie","*", ["AND" =>["user_id_usera" => $_SESSION["id_usera"], "czy_oplacono" => null]])){ //stworzenie koszyka jesli nie istnieje
            App::getDB()->insert("zamowienie", [
            "user_id_usera" => $_SESSION["id_usera"],
            ]);
        }
        App::getDB()->insert("egzemplarz", [ //stworzenie egzemplarza dodanego do koszyka
            "produkt_id_produkt" => $product,
            "zamowienie_id_zamowienia" => (App::getDB()->get("zamowienie","id_zamowienia", ["AND" =>["user_id_usera" => $_SESSION["id_usera"], "czy_oplacono" => null]])),
            ]);
        Utils::addInfoMessage("Dodano do koszyka ".$product.$koszyk);
        App::getRouter()->redirectTo("cartView");
        
    }
}
