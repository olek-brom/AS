<?php
namespace app\controllers;

use core\Validator;
use core\App;
use core\Utils;
use app\forms\UserForm;

class LoginCtrl {	
        private $form;

        public function __construct() {
            $this->form = new UserForm();
        }
        
	public function validate() {
                $v = new Validator();
                $this->form->uname = $v->validateFromRequest("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->psw = $v->validateFromRequest("psw", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $user = App::getDB()->get("user", "*",[
                "nazwa_usera" => $this->form->uname,
                ]);
                if(!$user) {
                    Utils::addErrorMessage("Użytkownik o podanym loginie nie istnieje");
                    return false;
                }
                if (!password_verify($this->form->psw, $user['haslo'])) {
                    Utils::addErrorMessage("Niepoprawne hasło");
                    return false;
                }
                
                $role = App::getDB()->select("rola_has_user", "*",[
                "user_id_usera" => $user["id_usera"],
                ]);

                foreach($role as $rola) {
                    
                    $this->form->nazwa_roli = App::getDB()->get("rola", "nazwa_rola",[
                    "id_rola" => $rola["rola_id_rola"],
                    ]);
                    \core\RoleUtils::addRole($this->form->nazwa_roli);//zapisanie roli w sesji
                    $_SESSION["id_rola"] = $rola["rola_id_rola"];
                }
                $_SESSION["id_usera"] = $user["id_usera"];
                $_SESSION["user"] = $user["imie"]." ".$user["nazwisko"];
                return true;

	}
        
        public function validateRegister(){
                //1. pobranie parametrów formularza rejestracji
                $v = new Validator();
                $this->form->uname = $v->validateFromPost("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->psw = $v->validateFromPost("psw", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->pswRepeat = $v->validateFromPost("psw-repeat", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj powtórzone hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->name = $v->validateFromPost("name", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj imię',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->surname = $v->validateFromPost("surname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj nazwisko',
                ]);
                if (!$v->isLastOK()) return false;
                $this->form->email = $v->validateFromPost("email", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                'email' => true,
                ]);
                $this->form->address = $v->validateFromPost("address", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                ]);
                if (!$v->isLastOK()) return false;
                $user = App::getDB()->get("user", "*",[
                "nazwa_usera" => $this->form->uname,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym loginie już istnieje");
                    return false;
                }
                $user = App::getDB()->get("user", "*",[
                "e-mail" => $this->form->email,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym adresie e-mail już istnieje");
                    return false;
                }
                if($this->form->psw != $this->form->pswRepeat){
                    Utils::addErrorMessage("podane hasła nie zgadzają się");
                    return false;
                }
                return true;
        }

	public function action_loginView(){
                
		$this->generateView(); 
	}
        
        public function action_registerView(){
		$this->generateRegisterView(); 
	}
	
	public function action_login(){
		if ($this->validate()){
			//zalogowany => przekieruj na główną akcję 
                        App::getRouter()->redirectTo("hello");
                } else {
			//niezalogowany => pozostań na stronie logowania
			$this->generateView(); 
		}		
	}
	
	public function action_logout(){
		// 1. zakończenie sesji
		session_destroy();
		// 2. idź na stronę główną - system automatycznie przekieruje do strony logowania
		App::getRouter()->redirectTo('hello');
	}	
    
	public function action_register(){
            if ($this->validateRegister()){
                App::getDB()->insert("user", [
                "haslo" => password_hash($this->form->psw, PASSWORD_DEFAULT),
                "nazwa_usera" => $this->form->uname,
                "imie" => $this->form->name,
                "nazwisko" => $this->form->surname,
                "e-mail" => $this->form->email,
                "adres" => $this->form->address,
                "kto_zalozyl_user_id" => 1,
                "kto_modyfikowal_id_usera" => 1 
                ]);
                $this->form->id = App::getDB()->id();
                App::getDB()->query(
                "UPDATE <user> SET <kto_zalozyl_user_id> = :kto, <kto_modyfikowal_id_usera> = :kto WHERE <id_usera> = :kto", [
                    ":kto" => $this->form->id,
                ]);
                App::getDB()->insert("rola_has_user", [
                "rola_id_rola" => 3,
                "user_id_usera" => $this->form->id, 
                "aktywna" => 1,
                ]);
                $_SESSION["success"] = "Rejestracja powiodła się";
                App::getRouter()->redirectTo('loginView');
                } else {
                //niezarejestrowany => pozostań na stronie rejestracji
                $this->generateRegisterView(); 
            }		
	}
	
	public function generateView(){
            App::getSmarty()->assign('uname',$this->form->uname); // dane formularza do widoku
            App::getSmarty()->display('login.tpl');	
            unset($_SESSION["success"]);
	}
        public function generateRegisterView(){
            App::getSmarty()->assign('uname',$this->form->uname); // dane formularza do widoku
            App::getSmarty()->assign('name',$this->form->name); // dane formularza do widoku
            App::getSmarty()->assign('surname',$this->form->surname); // dane formularza do widoku
            App::getSmarty()->assign('email',$this->form->email); // dane formularza do widoku
            App::getSmarty()->assign('address',$this->form->address); // dane formularza do widoku
            App::getSmarty()->display('register.tpl');		
	}
}