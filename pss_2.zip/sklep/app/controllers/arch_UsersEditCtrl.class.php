<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\ParamUtils;
use core\Validator;

/**
 * HelloWorld built in Amelia - sample controller
 *
 * @author Przemysław Kudłacik
 */
class UsersEditCtrl {
    
    private $form;

    public function __construct() {
        $this->form = new UserForm();
    }
    
    
    private $records; //rekordy pobrane z bazy danych
    private $id; //id rekordu do edycji/usuniecia
    private $record; //rekord do edycji
    private $role; //rola rekord do edycji
        
    public function action_viewUsers() {
        try{
            $this->records = App::getDB()->select("rola_has_user", 
                    [
                       "[>]user" => ["user_id_usera" => "id_usera"] ,
                       "[>]rola" => ["rola_id_rola" => "id_rola"] 
                    ],
                    "*"
//                    [
//                        "user.nazwa_usera",
//                        "rola_has_user.rola_id_rola",
//                        "rola_has_user.user_id_usera",
//                        "rola_has_user.data_nadania",
//                    ]
                    );
        } catch (PDOException $e){
            echo 'PROBLEMY';
        }	

        // 4. wygeneruj widok
        //getSmarty()->assign('searchForm',$this->form); // dane formularza (wyszukiwania w tym wypadku)
        
        $this->prepareView();
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        
    }
    public function action_editUser() {
        if ( $this->validateEdit() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $this->record = App::getDB()->get("user", "*",[
                        "id_usera" => $this->id
                ]);
                $this->role = App::getDB()->get("rola_has_user",[
                "[>]rola" => ["rola_id_rola" => "id_rola"]
                ], "nazwa_rola",[
                        "user_id_usera" => $this->id
                ]);
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');			
        }
        $this->prepareView();
        App::getSmarty()->assign("record", $this->record);  // lista rekordów z bazy danych
        App::getSmarty()->assign("role", $this->role);
        App::getSmarty()->display("editUser.tpl");        
        }
        else {
        $this->prepareView();
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        }

    }
    
    
    
    public function action_deleteUser() {
        
    }
    
    //validacja danych przed wyswietleniem do edycji
    public function validateEdit() {
            //pobierz parametry na potrzeby wyswietlenia danych do edycji
            //z widoku listy osób (parametr jest wymagany)
            $v = new Validator();
            $this->id = $v->validateFromCleanURL(1);
            if (!$v->isLastOK()) {
                return false;
            }
        return true;
    }
    
    
    public function saveUser(){
        if ( $this->validateSave() ){
        try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $this->record = App::getDB()->get("user", "*",[
                        "id_usera" => $this->id
                ]);
                $this->role = App::getDB()->get("rola_has_user",[
                "[>]rola" => ["rola_id_rola" => "id_rola"]
                ], "nazwa_rola",[
                        "user_id_usera" => $this->id
                ]);
                
        } catch (PDOException $e){
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');			
        }
        $this->prepareView();
        App::getSmarty()->assign("record", $this->record);  // lista rekordów z bazy danych
        App::getSmarty()->assign("role", $this->role);
        App::getSmarty()->display("editUser.tpl");        
        }
        else {
        $this->prepareView();
        App::getSmarty()->assign('records',$this->records);  // lista rekordów z bazy danych
        App::getSmarty()->display("viewUsers.tpl");
        }

    }
    
    private function prepareView(){
        $kategorie = App::getDB()->select("kategoria", "*");
        App::getSmarty()->assign("kategorie",$kategorie);
    }
    
    public function validateSave(){
                //1. pobranie parametrów formularza rejestracji
                $v = new Validator();
                $this->uname = $v->validateFromPost("uname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj login',
                'validator_message' => 'Niepoprawny login',
                ]);
                if (!$v->isLastOK()) return false;
                $this->psw = $v->validateFromPost("psw", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->pswRepeat = $v->validateFromPost("psw-repeat", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj powtórzone hasło',
                ]);
                if (!$v->isLastOK()) return false;
                $this->name = $v->validateFromPost("name", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj imię',
                ]);
                if (!$v->isLastOK()) return false;
                $this->surname = $v->validateFromPost("surname", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj nazwisko',
                ]);
                if (!$v->isLastOK()) return false;
                $this->email = $v->validateFromPost("email", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                'email' => true,
                ]);
                $this->address = $v->validateFromPost("address", [
                'trim' => true,
                'required' => true,
                'required_message' => 'Podaj email',
                ]);
                if (!$v->isLastOK()) return false;
                $user = App::getDB()->get("user", "*",[
                "nazwa_usera" => $this->uname,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym loginie już istnieje");
                    return false;
                }
                $user = App::getDB()->get("user", "*",[
                "e-mail" => $this->email,
                ]);
                if($user) {
                    Utils::addErrorMessage("Użytkownik o podanym adresie e-mail już istnieje");
                    return false;
                }
                if($this->psw != $this->pswRepeat){
                    Utils::addErrorMessage("podane hasła nie zgadzają się");
                    return false;
                }
                return true;
    }
    
}
