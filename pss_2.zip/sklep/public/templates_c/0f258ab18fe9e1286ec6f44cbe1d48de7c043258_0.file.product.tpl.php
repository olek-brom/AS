<?php
/* Smarty version 4.1.0, created on 2023-01-15 20:12:57
  from 'C:\xampp\htdocs\sklep\app\views\product.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63c450392e5087_43809269',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0f258ab18fe9e1286ec6f44cbe1d48de7c043258' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\product.tpl',
      1 => 1673809906,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63c450392e5087_43809269 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_190285218863c450392b9a47_07072889', 'maincontent1');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'maincontent1'} */
class Block_190285218863c450392b9a47_07072889 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_190285218863c450392b9a47_07072889',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
    <div class="w3-panel w3-pale-yellow w3-round">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
        <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>    
    <?php }?>
    <?php if ((isset($_smarty_tpl->tpl_vars['pobrana']->value))) {?>
    <h1 class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['pobrana']->value;?>
</h1>
    <?php }?>    
    <?php if ((isset($_smarty_tpl->tpl_vars['product']->value))) {?>
    <h1 class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['product']->value;?>
</h1>
    <?php }?> 
    
    <?php if ((isset($_smarty_tpl->tpl_vars['produkty']->value))) {?>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['produkty']->value, 'produkt');
$_smarty_tpl->tpl_vars['produkt']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['produkt']->value) {
$_smarty_tpl->tpl_vars['produkt']->do_else = false;
?>
        <div class="columns">
            <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
addToCart">
                <div class="card">
                <img src=<?php echo $_smarty_tpl->tpl_vars['produkt']->value["sciezka_plik"];?>
 alt="Butelka" width="200" height="300">
                <h2 style="font-size:2vw;" class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['produkt']->value["nazwa_produktu"];?>
</h2>
                <p class="price"><?php echo $_smarty_tpl->tpl_vars['produkt']->value["cena_brutto_dla_klienta"];?>
 PLN</p>
                <p><?php echo $_smarty_tpl->tpl_vars['produkt']->value["opis"];?>
</p>
                <p><button class = " w3-bar-item w3-button w3-theme-l2" name="product" type="submit" value="<?php echo $_smarty_tpl->tpl_vars['produkt']->value["id_produkt"];?>
">Do koszyka</button></p>
                </div>
            </form>
        </div>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
/* {/block 'maincontent1'} */
}
