<?php
/* Smarty version 4.1.0, created on 2023-01-03 14:40:37
  from 'C:\xampp\htdocs\sklep\app\views\addUser.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63b43055769746_50465839',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bb9a032254766b35854a5bec713bd3033e073b55' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\addUser.tpl',
      1 => 1672753225,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63b43055769746_50465839 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_35972624263b43055752226_88282363', 'maincontent1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_79935946563b43055768b52_63013350', 'maincontent2');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "admin.tpl");
}
/* {block 'maincontent1'} */
class Block_35972624263b43055752226_88282363 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_35972624263b43055752226_88282363',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div class="w3-panel w3-pale-yellow w3-round">
            <p>Błąd:</p><br>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
            <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>    
    <?php }?>
    
    <h4 class="w3-bar-item w3-text-theme"><b>Utworzenie konta użytkownika</b></h4>
    <form class="w3-container" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
addUser" method="post">
    <label for="uname">login: </label>
    <input class="w3-input" id="uname" placeholder="wprowadź login Użytkownika" type="text" name="uname"  required/>
    <label for="psw">hasło: </label>
    <input class="w3-input" id="psw" placeholder="wprowadź hasło Użytkownika" type="password" name="psw"  required/><br />
    <label for="psw">powtórz hasło: </label>
    <input class="w3-input" id="psw-repeat" placeholder="powtórz hasło Użytkownika" type="password" name="psw-repeat"  required /><br />
    <label for="name">imię: </label>
    <input class="w3-input" id="name" placeholder="wprowadź imię Użytkownika" type="text" name="name" required/>
    <label for="surname">nazwisko: </label>
    <input class="w3-input" id="surname" placeholder="wprowadź nazwisko Użytkownika" type="text" name="surname" required/>
    <label for="surname">e-mail: </label>
    <input class="w3-input" id="email" placeholder="wprowadź e-mail Użytkownika" type="text" name="email" required/>
    <label for="address">adres: </label>
    <input class="w3-input" id="address" placeholder="wprowadź adres Użytkownika" type="text" name="address" required/>
    <div class="">
            <input type="submit" value="Twórz Użytkownika" class="w3-brown w3-button w3-round-xxlarge"/>
    </div>
</form>

<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_79935946563b43055768b52_63013350 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_79935946563b43055768b52_63013350',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent2'} */
}
