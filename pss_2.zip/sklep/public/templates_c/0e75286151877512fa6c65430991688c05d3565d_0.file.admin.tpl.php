<?php
/* Smarty version 4.1.0, created on 2023-01-28 10:49:08
  from 'C:\xampp\htdocs\sklep\app\views\admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63d4ef948571d4_87996965',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0e75286151877512fa6c65430991688c05d3565d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\admin.tpl',
      1 => 1673517917,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63d4ef948571d4_87996965 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_65635927463d4ef944df1a6_56782142', 'navbut1act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17404327063d4ef944e6688_94890172', 'navbut1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_159630051263d4ef944e77c4_99719802', 'navbut1act');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_197524330063d4ef944e8582_66939132', 'navbut2');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_129107678063d4ef944e9262_99173942', 'navbut4');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_132151348363d4ef94674a23_49710370', 'navlog');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19416309563d4ef946f4f56_93360230', 'maincontent1');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "sketch.tpl");
}
/* {block 'navbut1act'} */
class Block_65635927463d4ef944df1a6_56782142 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1act' => 
  array (
    0 => 'Block_65635927463d4ef944df1a6_56782142',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

viewUsers
<?php
}
}
/* {/block 'navbut1act'} */
/* {block 'navbut1'} */
class Block_17404327063d4ef944e6688_94890172 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1' => 
  array (
    0 => 'Block_17404327063d4ef944e6688_94890172',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

Użytkownicy
<?php
}
}
/* {/block 'navbut1'} */
/* {block 'navbut1act'} */
class Block_159630051263d4ef944e77c4_99719802 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut1act' => 
  array (
    0 => 'Block_159630051263d4ef944e77c4_99719802',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'navbut1act'} */
/* {block 'navbut2'} */
class Block_197524330063d4ef944e8582_66939132 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut2' => 
  array (
    0 => 'Block_197524330063d4ef944e8582_66939132',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'navbut2'} */
/* {block 'navbut4'} */
class Block_129107678063d4ef944e9262_99173942 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navbut4' => 
  array (
    0 => 'Block_129107678063d4ef944e9262_99173942',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a class="w3-bar-item w3-hide-small w3-hide-medium w3-display-middle">Witaj <?php echo $_SESSION['user'];?>
</a>
<?php }
}
}
/* {/block 'navbut4'} */
/* {block 'navlog'} */
class Block_132151348363d4ef94674a23_49710370 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'navlog' => 
  array (
    0 => 'Block_132151348363d4ef94674a23_49710370',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ((isset($_SESSION['user']))) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout" class="w3-bar-item w3-button w3-hover-white w3-display-right">Wyloguj</a>
<?php } else { ?>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
loginView" class="w3-bar-item w3-button w3-hover-white w3-display-right">Zaloguj</a>    
<?php }
}
}
/* {/block 'navlog'} */
/* {block 'maincontent1'} */
class Block_19416309563d4ef946f4f56_93360230 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_19416309563d4ef946f4f56_93360230',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
    <div class="w3-panel w3-pale-yellow w3-round">
        <p>Błąd:</p><br>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
        <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>    
    <?php }?>
<div class="w3-text-theme">
    <h4 class="w3-bar-item"><b>Panel administracyjny</b></h4>
    <p>W panelu administracyjnym możesz:</p>
    <div class="">
        <ul class="w3-ul">
            <li><i class="fa fa-male w3-large w3-margin"></i> Edytować Użytkowników</li>
        </ul>
    </div>
</div>
<?php
}
}
/* {/block 'maincontent1'} */
}
