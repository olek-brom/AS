<?php
/* Smarty version 4.1.0, created on 2022-12-10 21:28:56
  from 'C:\xampp\htdocs\sklep\app\views\cart.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6394ec083b5aa1_57402106',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '46e4734de7c2d786db748bb0a55b4cb16340b1c9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\cart.tpl',
      1 => 1670698307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6394ec083b5aa1_57402106 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10661594346394ec0838de00_45148107', 'maincontent1');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6909970776394ec083b3fd2_45705020', 'maincontent2');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5330719236394ec083b4fa5_97304384', 'maincontent3');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'maincontent1'} */
class Block_10661594346394ec0838de00_45148107 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_10661594346394ec0838de00_45148107',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ((isset($_smarty_tpl->tpl_vars['pobrana']->value))) {?>
    <h1 class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['pobrana']->value;?>
</h1>
    <?php }?>    
    <?php if ((isset($_smarty_tpl->tpl_vars['product']->value))) {?>
    <h1 class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['product']->value;?>
</h1>
    <?php }?> 
    
    <?php if ((isset($_smarty_tpl->tpl_vars['produkty']->value))) {?>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['produkty']->value, 'produkt');
$_smarty_tpl->tpl_vars['produkt']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['produkt']->value) {
$_smarty_tpl->tpl_vars['produkt']->do_else = false;
?>
        <div class="columns">
            <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
addToCart">
                <div class="card">
                <img src=<?php echo $_smarty_tpl->tpl_vars['produkt']->value["sciezka_plik"];?>
 alt="Butelka" width="200" height="300">
                <h2 style="font-size:2vw;" class="w3-text-theme"><?php echo $_smarty_tpl->tpl_vars['produkt']->value["nazwa_produktu"];?>
</h2>
                <p class="price"><?php echo $_smarty_tpl->tpl_vars['produkt']->value["cena_brutto_dla_klienta"];?>
 PLN</p>
                <p><?php echo $_smarty_tpl->tpl_vars['produkt']->value["opis"];?>
</p>
                <p><button class = " w3-bar-item w3-button w3-theme-l2" name="product" type="submit" value="<?php echo $_smarty_tpl->tpl_vars['produkt']->value["id_produkt"];?>
">Dodaj do koszyka</button></p>
                </div>
            </form>
        </div>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_6909970776394ec083b3fd2_45705020 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_6909970776394ec083b3fd2_45705020',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent2'} */
/* {block 'maincontent3'} */
class Block_5330719236394ec083b4fa5_97304384 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent3' => 
  array (
    0 => 'Block_5330719236394ec083b4fa5_97304384',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'maincontent3'} */
}
