<?php
/* Smarty version 4.1.0, created on 2023-01-28 10:51:15
  from 'C:\xampp\htdocs\sklep\app\views\viewProducts.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63d4f013def379_00500036',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b36eb442013955e1f48a58688ead5f17f2bb411f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\viewProducts.tpl',
      1 => 1673518066,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63d4f013def379_00500036 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_85108567363d4f013dcbce8_33216558', 'maincontent1');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_133952382263d4f013dedf22_13767030', 'maincontent2');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "seller.tpl");
}
/* {block 'maincontent1'} */
class Block_85108567363d4f013dcbce8_33216558 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_85108567363d4f013dcbce8_33216558',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
<div class="w3-panel w3-pale-green w3-round">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
        <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div>
<?php }?>

    <h4 class="w3-bar-item w3-text-theme"><b>Nowy Produkt</b></h4>
    <a class="w3-brown w3-button w3-round-xxlarge" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
addProductView">Nowy Produkt</a>
    <br>
    
    <form class="" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
viewProducts" id="form">
	<h4 class="w3-bar-item w3-text-theme"><b>Wyszukiwanie</b></h4>
	<fieldset>
		<input type="text" placeholder="nazwa produktu" name="sf_nazwa_produktu" <?php if ((isset($_smarty_tpl->tpl_vars['searchForm']->value->nazwa_produktu))) {?> value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->nazwa_produktu;?>
"<?php }?> /><br />
		<input class="w3-brown w3-button w3-round-xxlarge" type="submit" value="Filtruj">
	</fieldset>
    </form>
    <br>
    
    <h4 class="w3-bar-item w3-text-theme"><b>Przegląd produktów</b></h4>
    <div class="w3-table w3-striped">
    <table id="tab_people">
    <thead>
            <tr class="w3-brown">
                    <th>Nazwa produktu</th>
                    <th>Opis</th>
                    <th>Cena brutto</th>
                    <th>Kategoria</th>
                    <th>opcje</th>
            </tr>
    </thead>
    <tbody>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['records']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
    <tr><td><?php echo $_smarty_tpl->tpl_vars['r']->value["nazwa_produktu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["opis"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena_brutto_dla_klienta"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["nazwa_kategorii"];?>
</td><td><a class="w3-button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
editProduct/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_produkt'];?>
">Edytuj</a>&nbsp;<a class="w3-button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
deleteProduct/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_produkt'];?>
">Usuń</a></td></tr>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
    </table>
    </div>
<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_133952382263d4f013dedf22_13767030 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_133952382263d4f013dedf22_13767030',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent2'} */
}
