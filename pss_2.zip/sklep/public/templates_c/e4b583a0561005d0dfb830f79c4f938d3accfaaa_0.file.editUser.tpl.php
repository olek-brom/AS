<?php
/* Smarty version 4.1.0, created on 2023-01-12 09:52:43
  from 'C:\xampp\htdocs\sklep\app\views\editUser.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_63bfca5b47fce2_04534259',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e4b583a0561005d0dfb830f79c4f938d3accfaaa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\sklep\\app\\views\\editUser.tpl',
      1 => 1672858944,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bfca5b47fce2_04534259 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_191334650263bfca5b1556f9_64561365', 'maincontent1');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_161100361463bfca5b47ded5_72672079', 'maincontent2');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_116139847163bfca5b47ef14_69598066', 'maincontent3');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "admin.tpl");
}
/* {block 'maincontent1'} */
class Block_191334650263bfca5b1556f9_64561365 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent1' => 
  array (
    0 => 'Block_191334650263bfca5b1556f9_64561365',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div class="w3-panel w3-pale-yellow w3-round">
            <p>Błąd:</p><br>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
            <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>    
    <?php }?>
<h4 class="w3-bar-item w3-text-theme"><b>Edycja użytkownika</b></h4>
<div>
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
saveUser" method="post" class="w3-container">
	<fieldset>
            <legend>Dane użytkownika</legend>
            <label for="uname">ID</label>
            <input id="id" type="text" placeholder="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['id_usera'];?>
" readonly>
            <label for="uname">Nazwa Użytkownika</label>
            <input id="uname" type="text" placeholder="login" name="uname" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['nazwa_usera'];?>
" readonly>
            <label for="email">E-mail</label>
            <input id="email" type="text" placeholder="email" name="email" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['e-mail'];?>
">
            <label for="name">Imię</label>
            <input id="name" type="text" placeholder="imię" name="name" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['imie'];?>
">
            <label for="surname">Nazwisko</label>
            <input id="surname" type="text" placeholder="nazwisko" name="surname" value="<?php echo $_smarty_tpl->tpl_vars['record']->value['nazwisko'];?>
">
            <label for="nazwa_rola">Rola</label><br>
            <select name="id_roli" id="id_roli" class="w3-select">
            <option value="<?php echo $_smarty_tpl->tpl_vars['role']->value['id_rola'];?>
"><?php echo $_smarty_tpl->tpl_vars['role']->value['nazwa_rola'];?>
</option>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['roles']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['r']->value['id_rola'];?>
"><?php echo $_smarty_tpl->tpl_vars['r']->value['nazwa_rola'];?>
</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

            </select>
            <div class="">
                    <input type="submit" class="pure-button pure-button-primary" value="Zapisz"/>
                    <a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
viewUsers">Powrót</a>
            </div>
	</fieldset>
</form>	
</div>

<?php
}
}
/* {/block 'maincontent1'} */
/* {block 'maincontent2'} */
class Block_161100361463bfca5b47ded5_72672079 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent2' => 
  array (
    0 => 'Block_161100361463bfca5b47ded5_72672079',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent2'} */
/* {block 'maincontent3'} */
class Block_116139847163bfca5b47ef14_69598066 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'maincontent3' => 
  array (
    0 => 'Block_116139847163bfca5b47ef14_69598066',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'maincontent3'} */
}
