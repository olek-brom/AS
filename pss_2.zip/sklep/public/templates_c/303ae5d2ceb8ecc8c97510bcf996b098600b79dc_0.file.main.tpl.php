<?php
/* Smarty version 4.1.0, created on 2022-12-02 15:28:27
  from 'C:\xampp\htdocs\amelia\app\views\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_638a0b8b89fc58_20249519',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '303ae5d2ceb8ecc8c97510bcf996b098600b79dc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\amelia\\app\\views\\main.tpl',
      1 => 1669991302,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_638a0b8b89fc58_20249519 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1640647133638a0b8b89e0c9_48820570', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "sketch.tpl");
}
/* {block 'top'} */
class Block_1640647133638a0b8b89e0c9_48820570 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_1640647133638a0b8b89e0c9_48820570',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <p> to faktycznie rozszerza main</p>
<?php
}
}
/* {/block 'top'} */
}
